/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2herencia1;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author WALTER GOMEZ
 */
public class Prog2herencia1 {
    
// arraylist de objetos SeleccionBasquet / jugadores .  Independientemente de la clase hija a la que pertenezca el objeto
public static ArrayList<SeleccionBasquet> integrantes= new ArrayList<SeleccionBasquet>();
public static ArrayList<Jugadores> jugador= new ArrayList<Jugadores>();    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Entrenador SergioHernandez = new Entrenador (1,"Sergio","Hernandez", 54, "Entrenador Argentina");
        Jugadores LuisScola = new Jugadores(2,"Luis","Scola",40, 4, "ala-pivot");
        Masajista JuanRamirez = new Masajista(3,"Juan","Ramirez",46, "fisioterapista",18);
        Jugadores FacuCampazzo = new Jugadores(4,"Facu","Campazzo",29, 7, "base");
        Jugadores MarcosDelia = new Jugadores(5,"Marcos","Delia",27, 12, "pivot");
        PreFIsico LuisPerez = new PreFIsico(6,"Luis","Perez",52, "Prepador Fisico",22);
        
        integrantes.add(SergioHernandez);
        integrantes.add(LuisScola);
        integrantes.add(FacuCampazzo);
        integrantes.add(MarcosDelia);
        integrantes.add(JuanRamirez);
        integrantes.add(LuisPerez);
        
        jugador.add(LuisScola);
        jugador.add(FacuCampazzo);
        jugador.add(MarcosDelia);
        
        // actividad de concentrarse 
        JOptionPane.showMessageDialog(null, "Se procede a describir las actividades de la Selección de Basquet \n"+"Todos los integrantes de la Selección de Basquet realizan una concentración (se ejecutan los mismos metodos para todos)");
        for (SeleccionBasquet integrante : integrantes){
            JOptionPane.showMessageDialog(null, integrante.getNombre()+ " "+ integrante.getApellido()+ "  "+ integrante.getEdad()+ " años ");
            integrante.Concentrarse();
        } 
        
        // actividad de realizar viaje competitivo 
         JOptionPane.showMessageDialog(null, "Todos los integrantes de la Selección de Basquet viajan para jugar un partido. (se ejecutan los mismos metodos para todos)");
        for (SeleccionBasquet integrante : integrantes){
            JOptionPane.showMessageDialog(null, integrante.getNombre()+ " "+ integrante.getApellido()+ "  " +integrante.getEdad()+ " años  ");
            integrante.Viajar();
        } 
        // ----------------------------------------------------------
        // ejecucion de la clases hijas ----------------------
        // -----------------------------------------------------------
        // actividad de preparación fisica 
        JOptionPane.showMessageDialog(null, "Realizan actividades de preparación físcia son solamente Preparador fisico  y juagadores (se ejecutan metodos de  preparacion fisica)");
         JOptionPane.showMessageDialog(null, LuisPerez.getNombre()+ " "+  LuisPerez.getApellido()+ " " );
         LuisPerez.movEntrenamiento();
          for (Jugadores jugador : jugador){
            JOptionPane.showMessageDialog(null, jugador.getNombre()+ " "+ jugador.getApellido()+ " .... ");
            jugador.actFisica();
         } 
          // actividad de entrenamiento 
         JOptionPane.showMessageDialog(null, "Realizan entrenamiento son solamente entrenador y juagadores (se ejecutan metodos para  entrenar)");
         JOptionPane.showMessageDialog(null, SergioHernandez.getNombre()+ " "+  SergioHernandez.getApellido()+ " " );
         SergioHernandez.dirigirEntrena();
         for (Jugadores jugador : jugador){
            JOptionPane.showMessageDialog(null, "con el jugador ..."+jugador.getNombre()+ " "+ jugador.getApellido()+ "   nro camiseta : "+jugador.getNrocamiseta() );
            jugador.entrenar();
         } 
        // actividad de masajes        
        JOptionPane.showMessageDialog(null, "El masajista (tiene el metodo de dar masajes) realiza masajes a los jugadores  ...");
         JOptionPane.showMessageDialog(null, JuanRamirez.getNombre()+ "  " + JuanRamirez.getApellido()+ " " );                 
         JuanRamirez.darMasajes();
            for (Jugadores jugador : jugador){
            JOptionPane.showMessageDialog(null, "al jugador .."+ jugador.getNombre()+ " "+ jugador.getApellido()+ ".....  " );
            
            } 
           // actividad pre competitiva previo a  jugar el partido
         JOptionPane.showMessageDialog(null, "En la actividad pre competitiva participan el Preparador fisico  y los jugadores (se ejecutan metodos pre competitivo)");
         JOptionPane.showMessageDialog(null, LuisPerez.getNombre()+ " "+ LuisPerez.getApellido()+ " " );
         LuisPerez.movPreComp();
          for (Jugadores jugador : jugador){
            JOptionPane.showMessageDialog(null, "con el jugador ..."+jugador.getNombre()+ " "+ jugador.getApellido()+" .... ");
            jugador.actPreComp();
         } 
          // actividad de jugar el partido
         JOptionPane.showMessageDialog(null, "El partido participan el entrenador  y los jugadores (se ejecutan metodos jugar partido)");
         JOptionPane.showMessageDialog(null, SergioHernandez.getNombre()+ " "+SergioHernandez.getApellido()+ " " );
         SergioHernandez.dirigirPartido();
          for (Jugadores jugador : jugador){
            JOptionPane.showMessageDialog(null, jugador.getNombre()+ " "+ jugador.getApellido()+"   nro de camiseta  "+jugador.getNrocamiseta()+ "   puesto "+jugador.getPuesto() );
            jugador.jugarPartido();
         } 
         
    }
    
}
