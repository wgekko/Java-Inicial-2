/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2herencia1;

import javax.swing.JOptionPane;
/**
 *
 * @author WALTER GOMEZ
 */
public class PreFIsico extends SeleccionBasquet {
    
     private String titulo;
     private int aniotrab;
    
    // constructor
    public PreFIsico(){
        
    }
    // constructor recargadao
      public PreFIsico(int id, String nombre, String apellido, int edad, String titulo, int aniotrab){
          this.id = id;
         this.nombre = nombre;
         this.apellido = apellido;
         this.edad = edad;
         this.titulo = titulo;
         this.aniotrab = aniotrab;
          
    }
    
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    public void setAnioexp(int aniotrab) {
        this.aniotrab = aniotrab;
    }
    public String getTitulo() {
        return titulo;
    }
    public int getAniotrab() {
        return aniotrab;
    }
    public void movEntrenamiento(){
         JOptionPane.showMessageDialog(null, " ejercicio actividad fisica entrenamiento ....");
        
    }
    public void movPreComp(){
         JOptionPane.showMessageDialog(null, " ejercicio previo al partido ....");
        
    }
}
