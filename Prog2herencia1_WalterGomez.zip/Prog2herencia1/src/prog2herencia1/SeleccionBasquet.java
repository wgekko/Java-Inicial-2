/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2herencia1;

import javax.swing.JOptionPane;

/**
 *
 * @author WALTER GOMEZ
 */
public class SeleccionBasquet {
    protected int id;
    protected String nombre;
    protected String apellido;
    protected int edad;
    
    // constructor 
    public SeleccionBasquet(){
        
        
    }
    // constructor sobrecargado
     public SeleccionBasquet(int id, String nombre, String apellido, int edad){
         this.id = id;
         this.nombre = nombre;
         this.apellido = apellido;
         this.edad = edad ;
    }
     
    public void setId(int id) {
        this.id = id;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    
    public void setEdad(int edad) {
        this.edad = edad;
    }
    public int getId() {
        return id;
    }
    public String getNombre() {
        return nombre;
    }
    
    public String getApellido() {
        return apellido;
    }
    public int getEdad() {
        return edad;
    }
    public void Concentrarse(){
         JOptionPane.showMessageDialog(null, "se concentra ....");
    }
    public void Viajar(){
      JOptionPane.showMessageDialog(null, " viaja ....");   
        
    }
    
}
