/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2herencia1;

import javax.swing.JOptionPane;

/**
 *
 * @author WALTER GOMEZ
 */
public class Entrenador extends SeleccionBasquet {
     
    private String federacion;
     
     // constructor
    public Entrenador(){
        
    }
      public Entrenador(int id, String nombre, String apellido, int edad, String federacion){
         this.id = id;
         this.nombre = nombre;
         this.apellido = apellido;
         this.edad = edad;
         this.federacion = federacion;
    }
   
    public void setFederacion(String federacion) {
        this.federacion = federacion;
    }
    public String getFederacion() {
        return federacion;
    }
    public void dirigirPartido(){
        JOptionPane.showMessageDialog(null, "Dirige el partido");
        
    }
    public void dirigirEntrena(){
         JOptionPane.showMessageDialog(null, "Dirige  el entrenamiento");
    }
}
