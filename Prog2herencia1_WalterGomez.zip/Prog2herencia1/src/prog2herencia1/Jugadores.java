/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2herencia1;

import javax.swing.JOptionPane;

/**
 *
 * @author WALTER GOMEZ
 */
public class Jugadores extends SeleccionBasquet {
    
    private int nrocamiseta;
    private String puesto;
    
    // constructor
    public Jugadores(){
        
    }
    
     public Jugadores( int id, String nombre, String apellido, int edad, int nrocamiseta, String puesto){
         this.id = id;
         this.nombre = nombre;
         this.apellido = apellido;
         this.edad = edad;
         this.nrocamiseta = nrocamiseta;
         this.puesto = puesto;
    }

    public void setNrocamiseta(int nrocamiseta) {
        this.nrocamiseta = nrocamiseta;
    }
    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }
    
    public int getNrocamiseta() {
        return nrocamiseta;
    }
    public String getPuesto() {
        return puesto;
    }
    public void jugarPartido(){
         JOptionPane.showMessageDialog(null, "juega el  partido...");
    }
    public void entrenar() {
        JOptionPane.showMessageDialog(null, "entrena...");
    }
     public void actFisica(){
         JOptionPane.showMessageDialog(null, "haciendo ejercicios solicidatos por el preparador fisico...");
    }
    public void actPreComp() {
        JOptionPane.showMessageDialog(null, "haciendo actividad pre competitiva previo al partido...");
    }
    
    
}
