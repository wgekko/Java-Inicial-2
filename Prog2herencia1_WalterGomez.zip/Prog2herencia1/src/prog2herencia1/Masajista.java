/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2herencia1;

import javax.swing.JOptionPane;

/**
 *
 * @author WALTER GOMEZ
 */
public class Masajista extends SeleccionBasquet {
    
    private String titulo;
    private int anioexp;
    
    // constructor
    public Masajista(){
        
    }
     // constructor recargado 
      public Masajista(int id, String nombre, String apellido, int edad, String titulo, int anioexp){
          this.id = id;
         this.nombre = nombre;
         this.apellido = apellido;
         this.edad = edad;
         this.titulo = titulo;
         this.anioexp = anioexp;
          
    }
    
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    public void setAnioexp(int anioexp) {
        this.anioexp = anioexp;
    }
    public String getTitulo() {
        return titulo;
    }
    public int getAnioexp() {
        return anioexp;
    }
    public void darMasajes(){
         JOptionPane.showMessageDialog(null, "da los masajes....");
        
    }
}
