/*
 * desarrollo de TP3 de Laboratorio de Computación 1
 Ejercicio   # 1 consigna
1) Pedir que se ingrese por teclado un número y mostrar la tabla de multiplicar completa del 0 al 10.
   Imprimir el multiplicando, el multiplicador y el producto. 

 */
package tp3_ejercicios;

import java.util.Scanner;

/**
 *
 * @author WALTER GOMEZ
 */
public class TP3_Ejercicios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // se dearrolla este ejercicio con 3 opciones (for, while, do while)             
        // por la poder desplegar todos los números en forma consecutiva  se usa Scanner 
        Scanner ingreso = new Scanner (System.in);
        int opcion=0;        
        System.out.println("\n\t Menú de Opciones");
        System.out.println("1 - Tabla de Multiplicar con For");
        System.out.println("2 - Tabla de Multiplicar con While");
        System.out.println("3 - Tabla de Multiplicar con Do While");
        System.out.println("Digite el número de la opción elegida : ");
        opcion = ingreso.nextInt();
        
        
        if ( (opcion <= 0) || (opcion >3)){
            
            System.out.println("Error...!!, dato ingresado es invalido, vuelva a correr el programa...");
        }else{
            
            switch (opcion){
                case 1: // con For
                     Scanner sc = new Scanner(System.in);
                        int nro;
                        System.out.print("Introduce un número entero: ");                                                         
                        nro = sc.nextInt();

                        if (nro >0){

                            System.out.println("Tabla del " + nro);

                                for(int i = 1; i<=10; i++){
                                System.out.println(" - "+nro + " x " + i + " = " + nro*i);
                                }
                        }else{
                            System.out.println("Error!!!, el dato es invalido, vuelva a correr el programa...");    

                        }
                        System.out.println("\n fin del programa......!");    
                break;
                case 2: // con While 
                       Scanner entrada = new Scanner(System.in);
                        int num;
                        System.out.print("Introduce un número entero: ");                                                         
                        num = entrada.nextInt();

                    if (num >=0){    
                    int k;

                    k=1;

                        while (k < 11) {

                             System.out.println(" - "+num + " x " + k + " = " + num*k);

                            k=k+1;

                        }  
                    }else {
                         System.out.println("Error!!!, el dato es invalido, vuelva a correr el programa..."); 
                        
                    }
                    
                break;
                case 3: // con Do While
                     Scanner dato = new Scanner(System.in);
                        int numero;
                        System.out.print("Introduce un número entero: ");                                                         
                        numero = dato.nextInt();
                    if (numero > 0){
                    int j;
                    j=1;

                        do  {

                             System.out.println(" - "+numero + " x " + j + " = " + numero*j);

                            j= j+1;

                        }
                        while (j < 11);
                        
                    }else{
                        System.out.println("Error!!!, el dato es invalido, vuelva a correr el programa..."); 
                        
                    }
                    System.out.println("\n fin del programa......!");
                break;
                default:
                    System.out.println("el número seleccionado es incorrecto..");
            }
        }
   }
        
}       
        
        
        
        
        
        
        
        
        