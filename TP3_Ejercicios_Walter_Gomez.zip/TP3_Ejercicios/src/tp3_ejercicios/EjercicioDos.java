/*
 * Ejercicio # 2 
2) Leer 10 números e imprimir solamente los múltiplos de 2.
 */
package tp3_ejercicios;

import javax.swing.JOptionPane;

/**
 *
 * @author WALTER GOMEZ
 */
public class EjercicioDos {
        
    public static void main(String[] args) {
        // se generan 3 opciones para resolver este ejercicio 
        
        
        // opcion # 1 con For
        /*
         JOptionPane.showMessageDialog(null,"Debe digitar hasta 10 números .....");
        
         
        for (int i = 1; i < 11; i++) {
            int n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese "+i+"/10 números "));
            
            if (n%2==0){
                
                JOptionPane.showMessageDialog(null,"El número ingresado "+n+" - SI -es multiplo de 2...");
            
            }else{
                JOptionPane.showMessageDialog(null,"El número ingresado "+n+" - NO - es multiplo de 2...");
            }
        }*/
        
         // opcion # 2 con while
        /*
        JOptionPane.showMessageDialog(null,"Debe digitar hasta 10 números .....");
        
         int i=1;
         
        while ( i < 11) {
            
            int n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese "+i+"/10 números "));
            
            if (n%2==0){
                
                JOptionPane.showMessageDialog(null,"El número ingresado "+n+" - SI - es multiplo de 2...");
            
            }else{
                JOptionPane.showMessageDialog(null,"El número ingresado "+n+" - NO - es multiplo de 2...");
            }
            i++;
        }  */ 

            // opcion # 3 con do while
        
        JOptionPane.showMessageDialog(null,"Debe digitar hasta 10 números .....");
        
         int i=1;
         
        do  {
            
            int n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese "+i+"/10 números "));
            
            if (n%2==0){
                
                JOptionPane.showMessageDialog(null,"El número ingresado "+n+" - SI - es multiplo de 2...");
            
            }else{
                JOptionPane.showMessageDialog(null,"El número ingresado "+n+" - NO - es multiplo de 2...");
            }
            i++;
        }  
        while ( i < 11);
        
        
        JOptionPane.showMessageDialog(null,"Fin del programa ....!!!");
        
    }    
}    

            