/*
 *  * Ejercicio # 9 
En un supermercado una clienta pone en su carrito los articulos que va tomando de los estantes.
La señora quiere asegurarse de que el cajero le cobre bien lo que ella ha comprado. 
por lo que cada vez que toma un articulo anota su nombre, su precio, junto con la 
cantidad de articulos iguales que ha tomado y determina cuánto dinero gastará
en ese articulo; a esto le suma lo que irá gastando en los demás articulos, hasta 
que decide que ya tomó todo lo que necesitaba, Ayudele a esta señora  a obtener el total
de sus compras. En deseable que antes de pagar, la señora tenga en pantalla, la lista
completa de articulos, con sus cantidades y sus precios. Y luego el total  a pagar.

Detalles:
1) Al iniciar el programa se debe dar al usuario una breve explicación de los que ocurrirá y el motivo por el cual se le pedirán los datos.
2) Los datos deben pedirse, controlando que se ingrese el dato correcto según el tipo esperado (si es un precio, se ingresará número, si es texto, letras).
3) Al ingresar cada dato, se debe preguntar al usuario si ingresará un dato más o terminará.
4) Al terminar se deben mostrar los resultados que indica cada ejercicio.
5) Es muy importante la elección del tipo de variable que recibirá las respuestas del usuario.
 */
package tp3_ejercicios;

import java.util.Scanner;

/**
 *
 * @author WALTER GOMEZ
 */
public class EjercicioNueve {
    
    public static void main(String[] args) {
        
        // declaro las variables 
        String nombre, salida = "", articulos = "";
        double px_u,px, total = 0;
        int cantidad;
        System.out.println(" - Se asiste a un supermercado - con la intención de controlar al cajero con el total de la compra");
        System.out.println(" - este programa simula ser un carrito de compras. en el cual va guardando ");
        System.out.println(" - por nombre el artículo a comprar, la cantidad del mismo como asi también precio unitario y total : ");
        System.out.println(" - y al final final nos proporciona la suma total por la compra \n");
        // genero el bucle 
        do {
            System.out.println("Nombre del artículo : ");
            nombre = new Scanner(System.in).nextLine().trim();
            if ( (nombre.isEmpty()) || (nombre.length()<2)  || (nombre.matches("\\d*")) ){
                System.out.println("Error !!.., se ingreso nombre de articulo vacio, menor a tres letras o numérico, ejecute el programa nuevamente... ");
                break;
            }
            System.out.println("Cantidad : ");
            cantidad = new Scanner(System.in).nextInt();
            if ((cantidad ==0) || (cantidad <0) ){
                 System.out.println("Error !!.., la cantidad no puede ser nula o menor a cero, ejecute el programa nuevamente... ");
                break;
                
            }
            System.out.println("Precio : ");
            px_u = new Scanner(System.in).nextDouble();
            if((px_u ==0) || (px_u <0)){
                System.out.println("Error !!.., el precio unitario no puede ser nulo o menor a cero, ejecute el programa nuevamente... ");
                break;
            }
            
            px = cantidad*px_u;
            System.out.print("Ha ingresado el artículo : " + nombre + " " + " - cantidad: " + cantidad  + " - precio unitario : $ "+ px_u +" "+ " - precio total : $ "+ px +"\n");
            System.out.println("Continuar cargando artículos: (si = s)/ (no = n)");
            salida = new Scanner(System.in).nextLine();
            
            total += px;
            articulos += "\n" + nombre + "\t"  + " - cantidad -  " + cantidad + "\t" + " $ "+ px ;
            
            
        } while (salida.equalsIgnoreCase("s"));
        System.out.println("Artículos: " + articulos);
        System.out.println("El total de la compra es: \t\t $ " + total);
        
        
    }
    
}
