/*
 * Ejercicio # 6 
Encontrar el menor valor de un conjunto de n números dados.

 */
package tp3_ejercicios;

import javax.swing.JOptionPane;

/**
 *
 * @author WALTER GOMEZ
 */
public class EjercicioSeis {
    
    public static void main(String[] args) {
        
         // se generan 3 opciones para resolver este ejercicio 
        // opcion # 1 con For
        
        int menor=1000000000;
         JOptionPane.showMessageDialog(null,"Recuerdo que debe digitar una - n - cantidad de números\n para verificar ¿cuál? es el menor ");
         int dato = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de números..."));
         
        for (int i = 0; i <dato ; i++) {
            
            int n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese "+(i+1)+"/"+dato+" números "));
            
            if (n < menor){
                
                menor = n;
                           
            }
        }
        
        JOptionPane.showMessageDialog(null,"De un total de "+dato+" números ingresados - \n - el menor valor es : "+menor+" - ");         
        JOptionPane.showMessageDialog(null,"Fin del programa ....!!!");
        
        
            // opcion # 2 con while
 /*          
            int menor=1000000000;
         JOptionPane.showMessageDialog(null,"Recuerdo que debe digitar una - n - cantidad de números\n para verificar ¿cuál? es el menor ");
         int dato = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de números..."));
        int=1;
        while (i == dato) {
            
            int n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese "+i+"/"+dato+" números "));
            
            if (n < menor){
                menor = n;
           }
           i++;
        }
        
        JOptionPane.showMessageDialog(null,"De un total de "+dato+" números ingresados - \n - el menor valor es : "+menor+" - ");         
        JOptionPane.showMessageDialog(null,"Fin del programa ....!!!");
            
            
            
            
            
            
 */         
            // opcion # 3 con do while
 /*
         int menor=1000000000;
         JOptionPane.showMessageDialog(null,"Recuerdo que debe digitar una - n - cantidad de números\n para verificar ¿cuál? es el menor ");
         int dato = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de números..."));
        int=1;
        do {
            
            int n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese "+i+"/"+dato+" números "));
            
            if (n < menor){
                menor = n;
           }
           i++;
        }
        while (i == dato);
            
            
        JOptionPane.showMessageDialog(null,"De un total de "+dato+" números ingresados - \n - el menor valor es : "+menor+" - ");         
        JOptionPane.showMessageDialog(null,"Fin del programa ....!!!");
   
            
*/     
    }
    
}
