/*
 * Ejercicio # 10
10) Un teatro otorga descuentos según la edad del cliente. 
Determine la cantidad de dinero que el teatro percibe por cada una de las categorías. 
Considere que los niños menores de 5 años no pueden entrar al teatro 
y que existe un precio único en los asientos que deberá consultar con la administración del teatro. 
Los descuentos se hacen tomando en cuenta el siguiente cuadro:
	Categoría			Edad			Descuento
		1			  5 - 14                   35 %
                2			15 - 19			   25 %
		3			20 - 45 		     0%
		4			46 - 65			   25 %
		5			66 en adelante		   35 %


 */
package tp3_ejercicios;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;

/**
 *
 * @author WALTER GOMEZ
 */
public class EjercicioDIez {
      
    public static void main(String[] args) {
           // declaro las variables 
        DecimalFormat formato = new DecimalFormat("#.00");    
        int dato=0; 
        double edad_11=0,edad_12=0,edad_13=0,edad_14=0, edad_15=0;
        double ac_edad_11=0,ac_edad_12=0,ac_edad_13=0,ac_edad_14=0,ac_edad_15=0;
        double ac_dato_11=0,ac_dato_12=0,ac_dato_13=0,ac_dato_14=0,ac_dato_15=0;
        double ac_boleto_11=0,ac_boleto_12=0,ac_boleto_13=0,ac_boleto_14=0,ac_boleto_15=0;
        double desctotales= 0, vtastotales = 0,ac_dato=0;
        
        String r ="s";
        // abro cuadro de dialogos para comenzar a pedir datos 
        JOptionPane.showMessageDialog(null,"Un teatro otorga descuentos según la edad del cliente.\n "
                + "Determine la cantidad de dinero que el teatro percibe por cada una de las categorías.\n Considere que los niños menores de 5 años no pueden entrar al teatro \n"
                + "y que existe un precio único en los asientos que deberá consultar con la administración del teatro.");
         
            do {     
                                       
                     // declaro numero y verifico que el ingreso del dato no sea erroneo    
                    dato = Integer.parseInt(JOptionPane.showInputDialog(null,"¿ Por favor, ingrese el valor de la entrada  : $ "));    
                    if (  dato <= 0  ){
                              JOptionPane.showMessageDialog(null,"Error en el ingreso datos, verificar...!!, vuelva a correr el programa...");
                                break;
                    }  
                    
                    int edad = Integer.parseInt(JOptionPane.showInputDialog(null,"¿ El cuadro de descuento que se aplica al valor de la entreda es el siguiente :\n"
                            + " - debe ingresar un valor relacionado con las siguientes opciones : "
                            + "\n\t ( 1 : Niños menores a 5 añoes) "
                            + "\n\t ( 2: Niños de 5 a 14 años - descuentos 35% ) "
                            + "\n\t ( 3: Personas de 15 a 19 años, descuento 25% ) "
                            + "\n\t ( 4: Personas de 20 a 45 años, no tiene descuento ) "
                            + "\n\t ( 5: Personas de 46 a 65 años, descuento 25% )"
                            + "\n\t ( 6: Personas mayores a 66 años, descuento 35% ) "
                            + "\n\t ( 7: Salir de sistema "));   
                    if (  ( edad == 0) || (edad > 7) || (edad < 0) ){
                              JOptionPane.showMessageDialog(null,"Error en el ingreso datos, verificar...!!, vuelva a correr el programa...");
                                break;
                    }  
                    switch (edad){
                        case 1: 
                            if (edad <5 ){
                                 JOptionPane.showMessageDialog(null,"el niño es menor de 5 años, consulta con la Administracion disponibilidades...");
                                
                            }
                            break;
                        case 2: 
                            
                            edad_11 = dato*0.35; 
                            ac_dato_11 = ac_dato_11 + dato;
                            ac_edad_11 = ac_edad_11 + edad_11;    
                            ac_boleto_11 = ac_dato_11 - ac_edad_11 ; 
                           
                            break;
                        case 3: 
                            
                            edad_12 = dato*0.25; 
                            ac_dato_12 = ac_dato_12 + dato;
                            ac_edad_12 = ac_edad_12 + edad_12;    
                            ac_boleto_12 = ac_dato_12 - ac_edad_12; 
                            
                            break;
                        case 4: 
                            
                            ac_dato_13 = ac_dato_13 + dato;
                            ac_edad_13 = ac_edad_13 + edad_13;    
                            ac_boleto_13 = ac_dato_13- ac_edad_13; 
                           
                            break;
                        case 5: 
                          
                            edad_14 = dato*0.25; 
                            ac_dato_14 = ac_dato_14 + dato;
                            ac_edad_14 = ac_edad_14 + edad_14;    
                            ac_boleto_14 = ac_dato_14 - ac_edad_14; 
                          
                            break;
                        case 6: 
                            
                            edad_15 = dato*0.35; 
                            ac_dato_15 = ac_dato_15 + dato;
                            ac_edad_15 = ac_edad_15 + edad_15;    
                            ac_boleto_15 = ac_dato_15 - ac_edad_15;
                            
                            break;
                        case 7: 
                            JOptionPane.showMessageDialog(null,"Salió con exito del sistema.....");
                            break;
                        default:
                            JOptionPane.showMessageDialog(null,"ERROR !! , verificar datos ingresados.....");
                    }
       
                    r =JOptionPane.showInputDialog("Desea continuar calculando descuentos ?....(si = s / no = n) ").trim(); 
                    // verifico que la respuesta si no es afirmativa detenga el programa
                    
                    if (  (r.isEmpty()) || (r.matches("\\d*")) ){ // si la respuesta no es correcta se detiene el programa
                              JOptionPane.showMessageDialog(null,"Error en el ingreso respuesta (vacio), verificar...!!, vuelva a correr el programa...");
                                break;
                    }         
     
            }
                        
            while (r.equals("s"));
     
    desctotales= ac_edad_11 + ac_edad_12 + ac_edad_13 + ac_edad_14 + ac_edad_15;
    vtastotales = ac_boleto_11 + ac_boleto_12 + ac_boleto_13 + ac_boleto_14 + ac_boleto_15; 
    
    JOptionPane.showMessageDialog(null, "El monto total de boletos netos vendidos asciende a $  "+formato.format(vtastotales)+"\n"
            + "\n - el monto total de descuentos asciende a $ "+formato.format(desctotales)+"\n\n - monto total percibido por la catergiria # 1 : $ "+formato.format(ac_boleto_11)+
            "\n - monto total percibido por la catergiria # 2 : $ "+formato.format(ac_boleto_12)+"\n - monto total percibido por la catergiria # 3 : $ "+formato.format(ac_boleto_13)+
            "\n - monto total percibido por la catergiria # 4 : $ "+formato.format(ac_boleto_14)+"\n - monto total percibido por la catergiria # 5 : $ "+formato.format(ac_boleto_15)+"\n");   

    JOptionPane.showMessageDialog(null, "se salio del programa");
  
    }
    
}
