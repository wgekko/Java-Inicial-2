/*
 * Ejercicio # 4 
Suponga que se tiene un conjunto de calificaciones de un grupo de 40 alumnos.
Realizar un algoritmo para calcular la calificación media y la calificación más baja de todo el grupo.

 */
package tp3_ejercicios;

import javax.swing.JOptionPane;

/**
 *
 * @author WALTER GOMEZ
 */
public class EjercicioCuatro {
    
    public static void main(String[] args) {
        
          // se generan 3 opciones para resolver este ejercicio 
               
        // opcion # 1 con For
      
        float promedio=0,suma=0;
        int notabaja=10;               
        
         JOptionPane.showMessageDialog(null,"Debe digitar 40 calificaciones de alumnos........\n (para obtener el promedio y las calificación  más baja .....");
                 
        for (int i = 1; i < 41; i++) {
           
            int n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese "+i+"/40 números (entre 0 y 10 ) "));
            
            
                if (n < notabaja){
                    notabaja = n;
                }

               suma = suma + n;
               promedio = suma/40;
                                    
        }
    JOptionPane.showMessageDialog(null,"Sobre el total de calificaciones, de un grupo de 40 alumnos, \n - El promedio es : "+promedio+" - \n - la calificación más baja es :"+notabaja+" - ");         
    JOptionPane.showMessageDialog(null,"Fin del programa ....!!!");
         
            // opcion # 2 con while
 /*          
        float promedio=0,suma=0;
        int notabaja=10;          
            
         JOptionPane.showMessageDialog(null,"Debe digitar 40 calificaciones de alumnos........\n (para obtener el promedio y las calificación  más baja .....");
        
        int i=1;    
        while (i < 41) {
            int n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese "+i+"/40 números (entre 0 y 10 ) "));
            
                if (n < notabaja){
                    notabaja = n;
                }

               suma = suma + n;
               promedio = suma/40;
               
          i = i+1;              
        }
    JOptionPane.showMessageDialog(null,"Sobre el total de calificaciones, de un grupo de 40 alumnos, \n - El promedio es : "+promedio+" - \n - la calificación más baja es :"+notabaja+" - ");         
    JOptionPane.showMessageDialog(null,"Fin del programa ....!!!");
           
 */           
            // opcion # 3 con do while
 /*
      
            float promedio=0,suma=0;
            int notabaja=10;     
            
         JOptionPane.showMessageDialog(null,"Debe digitar 40 calificaciones de alumnos........\n (para obtener el promedio y las calificación  más baja .....");
        
        int i=1;    
        do {
            int n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese "+i+"/40 números (entre 0 y 10 ) "));
        
                if (n < notabaja){
                    notabaja = n;
                }

               suma = suma + n;
               promedio = suma/40;
               
          i = i+1;              
        }
        while (i < 41);    
    JOptionPane.showMessageDialog(null,"Sobre el total de calificaciones, de un grupo de 40 alumnos, \n - El promedio es : "+promedio+" - \n - la calificación más baja es :"+notabaja+" - ");         
    JOptionPane.showMessageDialog(null,"Fin del programa ....!!!");
   
   */     
    }
}
