/*
 * Ejercicio # 11
Ejercicio # 1
En la Camara de Diputados se levanta una encuesta con todos los integrantes, 
   con el fin de determinar qué porcentaje de ellos está a favor del Tratado de libre comercio
   que porcentaje está en contra y que porcentaje se abstiene de opinar. 
   es deseable que al terminar, no sólo se muestren los porcentajes, sino tambien
   las respuestas obtenidas. 

Detalles:
1) Al iniciar el programa se debe dar al usuario una breve explicación de los que ocurrirá y el motivo por el cual se le pedirán los datos.
2) Los datos deben pedirse, controlando que se ingrese el dato correcto según el tipo esperado (si es un precio, se ingresará número, si es texto, letras).
3) Al ingresar cada dato, se debe preguntar al usuario si ingresará un dato más o terminará.
4) Al terminar se deben mostrar los resultados que indica cada ejercicio.
5) Es muy importante la elección del tipo de variable que recibirá las respuestas del usuario.

 */
package tp3_ejercicios;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;

/**
 *
 * @author WALTER GOMEZ
 */
public class EjercicioOnce {
    public static void main(String[] args) { 
    // declaro las variables 
        int votos=0,favor=0,contra=0,abst=0; 
        
        String r ="s";
        // abro cuadro de dialogos para comenzar a pedir datos 
        JOptionPane.showMessageDialog(null,"Se desea confeccionar una encuestas para saber, la posición de los Diputados (a favor, en contra, o se abstienen) sobre el Tratado de libre comercio....! ");
         r =JOptionPane.showInputDialog("iniciamos la encuestas...? (si = s / no = n)").trim();
        
        // verifico que el ingreso de los datos no sean erroneos
        
        if (r.isEmpty()||(r.matches("\\d*"))){
            JOptionPane.showMessageDialog(null,"Error en el ingreso de la respuesta, vuelva a correr el programa...");
                       
        }
          
        //if (r.equals("s")){       // si la respuesta es afirmativa 
          
            while (r.equals("s")){     
                                       
                     // declaro numero y verifico que el ingreso del dato no sea erroneo                   
                    int num = Integer.parseInt(JOptionPane.showInputDialog(null,"¿ Esta a favor del Tratado de Libre Comercio (a favor = 1,en contra = 2, abstiene = 3 ): "));   
                    if (  (num == 0) || (num >= 4) || (num < 0) ){
                              JOptionPane.showMessageDialog(null,"Error en el ingreso datos, verificar...!!, vuelva a correr el programa...");
                                break;
                    }  
                    r =JOptionPane.showInputDialog("quiere seguir?....(si = s / no = n) ").trim(); 
                    // verifico que la respuesta si no es afirmativa detenga el programa
                    
                    if (  r.isEmpty() ||(r.matches("\\d*")) ){
                              JOptionPane.showMessageDialog(null,"Error en el ingreso respuesta (vacio), verificar...!!, vuelva a correr el programa...");
                                break;
                    }     
                     
                     // se genera dentro del swicht la parte de donde se acumula las sumatoria de las respuestas 
                    switch(num){
                        case 1:
                        favor ++;
                        break;
                        case 2:
                        contra ++;
                        break;
                        case 3:
                        abst ++;
                        break;
                        default: 
                         JOptionPane.showMessageDialog(null,"Error en el ingreso datos, verificar...!");
                         break;
                    }
               
                votos ++;     
            
                
        }        
        // seccion del codigo donde se calcula el porcentaje de los votos. 
     DecimalFormat formato = new DecimalFormat("#.00");    
     double por1= (favor*100.0/votos); 
     double por2= (contra*100.0/votos); 
     double por3= (abst*100.0/votos);  
    
    JOptionPane.showMessageDialog(null, " - Sobre un total de "+votos+" votos\n - afirmativos fueron  : "+favor+" - porcentual de ("+formato.format(por1)+"%)\n - en contra fueron     : "+contra+" - porcentual de ("+formato.format(por2)+"%) \n -  abstenciones fueron : "+abst+" - porcentual de ("+formato.format(por3)+"%)");   

   
    JOptionPane.showMessageDialog(null, "se salio del programa"); 
        
    }        
}        
        
/*      
     public static void main(String[] args) {   

      // declaro las variables 
        int votos=0,favor=0,contra=0,abst=0; 
        
        String r ="s";
        // abro cuadro de dialogos para comenzar a pedir datos 
        JOptionPane.showMessageDialog(null,"Se desea confeccionar una encuestas para saber, la posición de los Diputados\n (a favor, en contra, o se abstienen) sobre el Tratado de libre comercio....! ");
         r =JOptionPane.showInputDialog("iniciamos la encuestas...? (si = s / no = n)").trim();
        
        // verifico que el ingreso de los datos no sean erroneos
        
        if ( (r.isEmpty()) || (r.matches("\\d*"))){
            JOptionPane.showMessageDialog(null,"Error en el ingreso de la respuesta, vuelva a correr el programa...");
                       
        }
          
              // si la respuesta es afirmativa 
          
            while (r.equals("s")){     
                                       
                     // declaro numero y verifico que el ingreso del dato no sea erroneo                   
                    int num = Integer.parseInt(JOptionPane.showInputDialog(null,"¿ Cúal es su posición frente al Tratado de Libre Comercio? \n  - digite la opción elegida - \n\t ( 1 : a favor) \n\t ( 2: en contra  ) \n\t ( 3: se abstiene ) "));   
                    if (  (num == 0) || (num >= 4) || (num < 0) ){
                              JOptionPane.showMessageDialog(null,"Error en el ingreso datos, verificar...!!, vuelva a correr el programa...");
                                break;
                    }  
                    r =JOptionPane.showInputDialog("continua con la encuesta?....(si = s / no = n) ").trim(); 
                    // verifico que la respuesta si no es afirmativa detenga el programa
                    
                    if (  (r.isEmpty()) || (r.matches("\\d*")) ){ // si la respuesta no es correcta se detiene el programa
                              JOptionPane.showMessageDialog(null,"Error en el ingreso respuesta (vacio), verificar...!!, vuelva a correr el programa...");
                                break;
                    }         
            
                    
                    if (num == 1){
                          favor ++;
                    }else {
                        if ( num == 2 ){
                            contra ++;
                        }else {
                            abst ++;
                        }
                    }
                votos ++; 
                    
            }
    DecimalFormat formato = new DecimalFormat("#.00");    
    double por1= (favor*100.0/votos); 
    double por2= (contra*100.0/votos); 
    double por3= (abst*100.0/votos);  
    
    JOptionPane.showMessageDialog(null, " - Sobre un total de "+votos+" votos\n - afirmativos fueron  : "+favor+" - porcentual de ("+formato.format(por1)+"%)\n - en contra fueron     : "+contra+" - porcentual de ("+formato.format(por2)+"%) \n -  abstenciones fueron : "+abst+" - porcentual de ("+formato.format(por3)+"%)");   

    JOptionPane.showMessageDialog(null, "se salio del programa");  
    
}
}*/
