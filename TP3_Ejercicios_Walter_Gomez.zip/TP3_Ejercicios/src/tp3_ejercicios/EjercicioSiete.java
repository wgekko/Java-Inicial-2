/*
 * Ejercicio # 7 
7) Una persona desea invertir su dinero en un banco, el cual le otorga un 2% de interés. 
¿Cuál será la cantidad de dinero que esta persona tendrá al cabo de un año si la ganancia de cada mes es reinvertida?
considero que el interes es mensual 
 */
package tp3_ejercicios;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;

/**
 *
 * @author WALTER GOMEZ
 */
public class EjercicioSiete {
    
    public static void main(String[] args) {
        
          // se generan 3 opciones para resolver este ejercicio 
        // opcion # 1 con For
                
        double montom=0,montot=0;
        int capital=0;
        
        JOptionPane.showMessageDialog(null,"Una Persona invertir su dinero, el banco le ofrece una capitalización mensual 2%\n y desea saber ¿Cúal? es su monto total al termino de un año ");
         capital = Integer.parseInt(JOptionPane.showInputDialog("Por favor, Ingrese el capital a invertir..."));
        
        if (capital > 0){  // valido le valor de la variable
        
            montom = capital * 1.02;
            for (int i = 0; i <11 ; i++) {
            
                montom = montom *1.02;      
                montot = montom;
            }
            
        }else {
            JOptionPane.showMessageDialog(null,"Error !!!, dato de capital es incorrecto  ....!!!");
           
        }
        DecimalFormat formato = new DecimalFormat("#.00");   
        JOptionPane.showMessageDialog(null,"El capital invertido fue de : "+capital+"\n - se obtuvo un interes anual de : "+formato.format(montot-capital)+"\n - monto total a termino del año : "+formato.format(montot));         
        JOptionPane.showMessageDialog(null,"Fin del programa ....!!!");
        
       
            // opcion # 2 con while
           
/*            
         double montom=0,montot=0;
        int capital=0;
        int i= 1;
        JOptionPane.showMessageDialog(null,"Una Persona invertir su dinero, el banco le ofrece una capitalización mensual 2%\n y desea saber ¿Cúal? es su monto total al termino de un año ");
         capital = Integer.parseInt(JOptionPane.showInputDialog("Por favor, Ingrese el capital a invertir..."));
        
        if (capital > 0){  // valido el valor de la variable
        
            montom = capital * 1.02;
            while (i <12) {
            
                montom = montom *1.02; 
                montot = montom;
                i++;
            }
            
        }else {
            JOptionPane.showMessageDialog(null,"Error !!!, dato de capital es incorrecto  ....!!!");
 
        }
        DecimalFormat formato = new DecimalFormat("#.00");   
        JOptionPane.showMessageDialog(null,"El capital invertido fue de : "+capital+"\n - se obtuvo un interes anual de : "+formato.format(montot-capital)+"\n - monto total a termino del año : "+formato.format(montot));         
        JOptionPane.showMessageDialog(null,"Fin del programa ....!!!");    
*/
        
            // opcion # 3 con do while
 /*
      
        double montom=0,montot=0;
        int capital=0;
        int i= 1;
        JOptionPane.showMessageDialog(null,"Una Persona invertir su dinero, el banco le ofrece una capitalización mensual 2%\n y desea saber ¿Cúal? es su monto total al termino de un año ");
         capital = Integer.parseInt(JOptionPane.showInputDialog("Por favor, Ingrese el capital a invertir..."));
        
        if (capital > 0){ // valido valor de la variable
        
            montom = capital * 1.02;
            do  {
            
                montom = montom *1.02; 
                montot = montom;
                i++;
            }
            while (i <12);
        }else {
            JOptionPane.showMessageDialog(null,"Error !!!, dato de capital es incorrecto  ....!!!");
           
        }
        DecimalFormat formato = new DecimalFormat("#.00");   
        JOptionPane.showMessageDialog(null,"El capital invertido fue de : "+capital+"\n - se obtuvo un interes anual de : "+formato.format(montot-capital)+"\n - monto total a termino del año : "+formato.format(montot));         
        JOptionPane.showMessageDialog(null,"Fin del programa ....!!!");    
         
*/     
        
        
    }
    
}
