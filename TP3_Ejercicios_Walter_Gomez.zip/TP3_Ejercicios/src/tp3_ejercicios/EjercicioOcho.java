/*
 * Ejercicio # 8 
8) En una tienda de descuento las personas que van a pagar el importe de su compra llegan a la caja y
sacan una bolita de color, que les dirá que descuento tendrán sobre el total de su compra. 
Determinar la cantidad que pagará cada cliente desde que la tienda abre hasta que cierra. 
Se sabe que si el color de la bolita es roja el cliente obtendrá un 40% de descuento; 
si es amarilla un 25% y si es blanca no obtendrá descuento.
 */
package tp3_ejercicios;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;

/**
 *
 * @author WALTER GOMEZ
 */
public class EjercicioOcho {
    // este ejercicio se desarrollo con el condicional IF, también se puede hacer con swicht
    public static void main(String[] args) {
           // declaro las variables 
        DecimalFormat formato = new DecimalFormat("#.00");    
        int blanca=0,roja=0,amarilla=0,compra_b=0; 
        double netopagar_r =0,netopagar_a =0,ac_amarilla=0,ac_roja=0;
        
        String r ="s";
        // abro cuadro de dialogos para comenzar a pedir datos 
        JOptionPane.showMessageDialog(null,"En una tienda  de descuento las personas que van el importe de la compra\n "
                + "llegan a la caja y sacan una bolita de color, que les dirá que descuento tendrán sobre el total de la compra.\n Determinar la cantidad que pagará cada cliente desde que la tienda abre hasta que la tienda cierra\n"
                + "Se sabe que si el color de la bolita es roja, el cliente obtendrá un 40% de descuento; si es amarilla un 25% y si es blanca no obtendrá descuento");
         r =JOptionPane.showInputDialog("la tienda esta abierta ?????.... (si = s / no = n)").trim();
        
        // verifico que el ingreso de los datos no sean erroneos
        
        if ( (r.isEmpty()) || (r.matches("\\d*"))){
            JOptionPane.showMessageDialog(null,"Error en el ingreso de la respuesta, vuelva a correr el programa...");
                       
        }
          
              // si la respuesta es afirmativa 
          
            while (r.equals("s")){     
                                       
                     // declaro numero y verifico que el ingreso del dato no sea erroneo    
                    int  compra = Integer.parseInt(JOptionPane.showInputDialog(null,"¿ Por favor, ingrese el monto total de su compra  : $ "));    
                    if (  compra <= 0  ){
                              JOptionPane.showMessageDialog(null,"Error en el ingreso datos, verificar...!!, vuelva a correr el programa...");
                                break;
                    }  
                    
                    int num = Integer.parseInt(JOptionPane.showInputDialog(null,"¿ Cúal es el color de la bolita de descuento que tiene ????\n  - digite la opción de acuerdo al color de la bolita - \n\t ( 1 : color blanco, sin descuento) \n\t ( 2: color rojo, descuento 40% ) \n\t ( 3: color amarillo, descuento 25& ) "));   
                    if (  (num == 0) || (num >= 4) || (num < 0) ){
                              JOptionPane.showMessageDialog(null,"Error en el ingreso datos, verificar...!!, vuelva a correr el programa...");
                                break;
                    }  
                    
                    
                    
                    if (num == 1){
                        blanca = compra;  
                        JOptionPane.showMessageDialog(null,"No tiene descuento Ud. debe pagar el total de la compra  $ "+formato.format(blanca));
                        compra_b =compra_b + blanca;  
                    }else {
                        if ( num == 2 ){
                            Double roja1; 
                            roja1 = Double.valueOf(roja);
                            roja1=  compra*0.4; 
                            ac_roja = ac_roja + roja1;
                            double netopagar = compra-roja1;
                            JOptionPane.showMessageDialog(null," Ud., compra por $"+compra+"\n tiene un descuento del 40% que asciende a $ "+formato.format(roja1)+"\n debe pagar un total de $ "+formato.format(netopagar));
                            netopagar_r = netopagar_r + netopagar;
                        }else {
                            Double amarilla1; 
                            amarilla1 = Double.valueOf(amarilla);
                            amarilla1=  compra*0.25; 
                            ac_amarilla = ac_amarilla + amarilla1; 
                            double netopagar1 = compra - amarilla1;
                            JOptionPane.showMessageDialog(null,"Ud., compra por $"+compra+"\ntiene un descuento del 25%, que asciende a $ "+formato.format(amarilla1)+"\n debe pagar un total de $ "+formato.format(netopagar1));
                            netopagar_a = netopagar_a + netopagar1;
                        }
                    }
                    
                    r =JOptionPane.showInputDialog("la tienda continua abierta?....(si = s / no = n) ").trim(); 
                    // verifico que la respuesta si no es afirmativa detenga el programa
                    
                    if (  (r.isEmpty()) || (r.matches("\\d*")) ){ // si la respuesta no es correcta se detiene el programa
                              JOptionPane.showMessageDialog(null,"Error en el ingreso respuesta (vacio), verificar...!!, vuelva a correr el programa...");
                                break;
                    }         
     
            }
     
    double desctotales=ac_roja+ac_amarilla;
    double vtastotales = 0;
    vtastotales = compra_b + netopagar_r + netopagar_a; 
    
    JOptionPane.showMessageDialog(null, "El total de ventas netas asciende a $  "+formato.format(vtastotales)+"\n - el total de descuentos asciende a $ "+formato.format(desctotales));   

    JOptionPane.showMessageDialog(null, "se salio del programa");
        
    }
    
}
