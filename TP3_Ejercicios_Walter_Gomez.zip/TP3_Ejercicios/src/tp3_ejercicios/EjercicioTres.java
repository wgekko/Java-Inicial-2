/*
 * Ejercicio # 3 
) Leer 20 números e imprimir cuántos son positivos, cuántos negativos y cuántos neutros.

 */
package tp3_ejercicios;

import javax.swing.JOptionPane;

/**
 *
 * @author WALTER GOMEZ
 */
public class EjercicioTres {
    
    public static void main(String[] args) {
        
          // se generan 3 opciones para resolver este ejercicio 
               
        // opcion # 1 con For
   /*     
        int positivo=0,negativo=0,neutro=0;
         JOptionPane.showMessageDialog(null,"Debe digitar hasta 20 números........\n (para verificar ¿cuántos? son positivos, negativos o neutros) .....");
                 
        for (int i = 1; i < 21; i++) {
            int n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese "+i+"/20 números "));
            
            if (n==0){
                
                neutro +=1;
                           
            }else{
                if (n > 0){
                    
                 positivo +=1;
                 
                }else {
                    
                    negativo +=1;
                }
            }
        }
        
        JOptionPane.showMessageDialog(null,"De un total de 20 números ingresados - \n - "+positivo+" - fueron positivos - \n - "+negativo+" - fueron negativos - \n - "+neutro+" - fueron neutros -");         
  
 */        
            // opcion # 2 con while
 /*          
      int positivo=0,negativo=0,neutro=0;
         JOptionPane.showMessageDialog(null,"Debe digitar hasta 20 números........\n (para verificar ¿cuántos? son positivos, negativos o neutros) .....");
              
         int i=1;
         
        while ( i < 21) {
            int n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese "+i+"/20 números "));
            
            if (n==0){
                
                neutro +=1;
                           
            }else{
                if (n > 0){
                    
                 positivo +=1;
                 
                }else {
                    
                    negativo +=1;
                }
            }
            i +=1;
        }
        
        JOptionPane.showMessageDialog(null,"De un total de 20 números ingresados - \n - "+positivo+" - fueron positivos - \n - "+negativo+" - fueron negativos - \n - "+neutro+" - fueron neutros -");         
  
   */         
            // opcion # 3 con do while
 
      int positivo=0,negativo=0,neutro=0;
         JOptionPane.showMessageDialog(null,"Debe digitar hasta 20 números........\n (para verificar ¿cuántos? son positivos, negativos o neutros) .....");
              
         int i=1;
         
         do {
            int n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese "+i+"/20 números "));
            
            if (n==0){
                
                neutro +=1;
                           
            }else{
                if (n > 0){
                    
                 positivo +=1;
                 
                }else {
                    
                    negativo +=1;
                }
            }
            i +=1;
        }
        while ( i < 21);
        JOptionPane.showMessageDialog(null,"De un total de 20 números ingresados - \n - "+positivo+" - fueron positivos - \n - "+negativo+" - fueron negativos - \n - "+neutro+" - fueron neutros -");         
  
        JOptionPane.showMessageDialog(null,"Fin del programa ....!!!");
              
    }
    
}
