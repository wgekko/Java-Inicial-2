/*
 * Ejercicio # 5 
Simular el comportamiento de un reloj digital, imprimiendo la hora,
minutos y segundos de un día desde las 0:00:00 horas hasta las 23:59:59 horas.
 */
package tp3_ejercicios;

/**
 *
 * @author WALTER GOMEZ
 */
public class EjercicioCinco {
    
    public static void main(String[] args) throws InterruptedException {
        
        int horas=0,minutos=0,segundos=0;
        
        while (true){
            
            // se muestra la salida por pantalla 
            if (horas <10){
                System.out.print("0");
                
            }
            System.out.print(horas+" : ");
            if (minutos <10){
                System.out.print("0");
                
            }
            System.out.print(minutos +" : ");
            if (segundos <10){
                System.out.print("0");
                
            }
            System.out.println(segundos);

            // se aumenta el tiempo
            segundos++;
            if(segundos ==60){
                segundos = 0;
                minutos++;
                if (minutos ==60){
                    minutos =0;
                    horas++;
                    if (horas ==24){
                        horas=0;
                    }
                }
            }
            Thread.sleep(100);
   
        }
        
    }
}
