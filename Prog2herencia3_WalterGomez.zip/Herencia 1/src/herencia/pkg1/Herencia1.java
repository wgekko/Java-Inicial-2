/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencia.pkg1;

/**
 *
 * @author WALTER GOMEZ
 */
public class Herencia1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Alumno alu1 = new Alumno(47031, "Walter", "Gomez", 54);
        Profesor prof1 = new Profesor("Ingeniero", "Martin ", "Vargas", 52);
        
        System.out.println("El nombre del alumno es " + alu1.getNombre());
        System.out.println("El apellido del alumno es " + alu1.getApellido());
        System.out.println("La edad del alumno es " + alu1.getEdad());
        System.out.println("El legajo del alumno es " + alu1.getLegajo());
        
        System.out.println("El nombre del profesor es " + prof1.getNombre());
        System.out.println("El apellido del profesor es " + prof1.getApellido());
        System.out.println("La edad del profesor es " + prof1.getEdad());
        System.out.println("El titulo del alumno es " + prof1.getTitulo());
    }
    
}
