/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencia.pkg1;

/**
 *
 * @author Enzo
 */
public class Profesor extends Persona{
    
    private String titulo;

    public Profesor() {
    }

    public Profesor(String titulo) {
        this.titulo = titulo;
    }

    public Profesor(String titulo, String nombre, String apellido, int edad) {
        super(nombre, apellido, edad);
        this.titulo = titulo;
    }

    /**
     * Get the value of titulo
     *
     * @return the value of titulo
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * Set the value of titulo
     *
     * @param titulo new value of titulo
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

}
