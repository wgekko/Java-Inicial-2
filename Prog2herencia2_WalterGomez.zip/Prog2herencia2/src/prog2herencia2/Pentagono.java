/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2herencia2;

/**
 *
 * @author WALTER GOMEZ
 */
public class Pentagono {
    
      private double lado1;
    private double apotema;

    public Pentagono() {
    }

    public Pentagono(double lado1, double apotema) {                                                               
        
        this.lado1 = lado1;
        this.apotema = apotema;
    }

    public double getLado1() {
        return lado1;
    }

    public void setLado1(double lado1) {
        this.lado1 = lado1;
    }

    public double getApotema() {
        return apotema;
    }

    public void setApotema(double apotema) {
        this.apotema =  apotema;
    }

    //Implementación del método abstracto area()                                                                  
    //heredado de la clase Polígono 
    
    public double area(){
        double Area;
        Area = ((lado1*5)*apotema)/2;
        return Area;
    }
    
    
}

